package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.dao.CustomerDao;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.MobileException;

public class CustomerServiceImpl implements CustomerService{

	
	
	public int addCustomer(CustomerBean custbean) throws  MobileException{
		
		CustomerDao obj=new CustomerDaoImpl();
		int pid=obj.addCustomer(custbean);
		return pid;
	}
	
	public List<MobileBean>viewAllMobiles() throws MobileException{
		
		CustomerDao obj=new CustomerDaoImpl();
		List<MobileBean> MblList=obj.viewAllMobiles();
		return MblList;
	}
	
	public int deleteMob(int id) throws MobileException{
		CustomerDao obj=new CustomerDaoImpl();
		id=obj.deleteMob(id);
		return id;
	}
		
	public List<MobileBean> searchmobile(int min,int max) throws MobileException{
			CustomerDao obj=new CustomerDaoImpl();
			List<MobileBean> mbllist =obj.searchmobile(min, max);
			return mbllist;
		}
	
public boolean validateCustomer(CustomerBean bean) throws MobileException
{
	 boolean validate=true;
	List<String> validationErrors = new ArrayList<String>();

	//Validating  name
	if(!(isValidName(bean.getCname()))) {
		validationErrors.add("\n Name Should Be In Alphabets and minimum 4 characters long and max 15 characters! \n");
	}
	
	//Validating Phone Number
	if(!(isValidPhoneNumber(bean.getPhoneno()))){
		validationErrors.add("\n Phone Number Should be in 10 digit \n");
	}
	
	if(!(isValidPhoneNumber(bean.getMailid()))){
		validationErrors.add("\n Mail id should follow pattern \n");
	}
	
	if(!validationErrors.isEmpty())
	{
		validate=false;
		throw new MobileException(validationErrors +"");
	}

	return validate;
}
	




		public boolean isValidName(String Name){
		Pattern namePattern=Pattern.compile("[A-Z][A-Za-z]{2,19}");
		Matcher nameMatcher=namePattern.matcher(Name);
		return nameMatcher.matches();
		}
		
		public boolean isValidemail(String email){
		Pattern phonePattern=Pattern.compile("[a-z0-9/_.+-]+@[a-z]{2,6}+.[a-z]{2,4}");
		Matcher phoneMatcher=phonePattern.matcher(email);
		return phoneMatcher.matches();
		}
		
		public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("[1-9][0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		}
		}
			
		
