package com.emp.service;

import java.util.List;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.exception.MobileException;

public interface CustomerService {

	
	public int addCustomer(CustomerBean custbean) throws  MobileException;
	public List<MobileBean>viewAllMobiles() throws MobileException;
	public int deleteMob(int id) throws MobileException;
	public List<MobileBean> searchmobile(int min,int max) throws MobileException;
	public boolean validateCustomer(CustomerBean bean) throws MobileException;
	
}
