package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.exception.MobileException;
import com.emp.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao {

	Scanner sc = new Scanner(System.in);

	Logger logger = Logger.getLogger(CustomerDaoImpl.class);

	public CustomerDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public int addCustomer(CustomerBean custbean) throws MobileException {

		// logger.debug("add emp from dao layer");
		// logger.info("Add Employee Called");
		// CREATE TABLE purchasedetails(purchaseid NUMBER, cname vARCHAR2(20),
		// mailid VARCHAR2(30),phoneno VARCHAR2(20), purchasedate DATE,
		// mobileid references mobiles(mobileid));
		int pid = 0;
		Connection con = null;
		String cmd = "insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,SYSDATE,?)";

		try {

			con = DBConnection.getConnection();
			pid = generatePurchaseId();
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1, pid);
			ps.setString(2, custbean.getCname());
			ps.setString(3, custbean.getMailid());
			ps.setString(4, custbean.getPhoneno());
			ps.setInt(5, custbean.getMobileid());
			int n = ps.executeUpdate();
			if (n == 0) {
				throw new MobileException("unable to insert");
			} else {
				String cmd1 = "update mobiles set quantity = quantity-1 where mobileid = ?";
				PreparedStatement ps1 = con.prepareStatement(cmd1);
				ps1.setInt(1, custbean.getMobileid());
				int i = ps1.executeUpdate();
				System.out.println(i);
			}
			con.close();

		} catch (Exception e) {
			// logger.error("unable to insert");
			e.printStackTrace();
			throw new MobileException("unable to insert");
		}
		return pid;
	}

	public int generatePurchaseId() throws MobileException {
		// logger.debug("generating employee id");
		// logger.info("generate Employee Called");
		int pid = 0;
		Connection con = null;
		String str = "select pid.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			pid = rs.getInt(1);
			// logger.info("Connection close");
			con.close();
		} catch (MobileException e) {
			throw new MobileException("unable to generate id");
			// e.printStackTrace();

		} catch (SQLException e) {
			throw new MobileException("unable to generate id");
		}
		return pid;
	}

	public List<MobileBean> viewAllMobiles() throws MobileException {
		Connection con = null;
		String cmd = "select * from mobiles";
		List<MobileBean> MblList = new ArrayList<MobileBean>();
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(cmd);

			while (rst.next()) {
				MobileBean bean = new MobileBean();
				bean.setMobileid(rst.getInt(1));
				bean.setName(rst.getString(2));
				bean.setPrice(rst.getInt(3));
				bean.setQuantity(rst.getString(4));
				MblList.add(bean);
			}
			return MblList;

		} catch (Exception e) {

			throw new MobileException("unable to view");
		}
	}

	public int deleteMob(int id) throws MobileException {
		Connection con = null;
		String cmd = "delete from mobiles where mobileid=" + id;
		String cmd1 = "delete from purchasedetails where mobileid=" + id;
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			int n = stmt.executeUpdate(cmd1);
			int i = stmt.executeUpdate(cmd);
			if (i == 0) {
				throw new MobileException("id not found");
			}
		} catch (MobileException e) {
			throw new MobileException("id not found");
		} catch (SQLException e) {
			throw new MobileException("id not found");
		}
		return id;
	}

	public List<MobileBean> searchmobile(int min, int max)
			throws MobileException {
		Connection con = null;

		List<MobileBean> MblList = new ArrayList<MobileBean>();
		try {
			con = DBConnection.getConnection();
			String cmnd = "select * from mobiles where price between " + min
					+ " and " + max;
			PreparedStatement stmt = con.prepareStatement(cmnd);
			ResultSet rst = stmt.executeQuery(cmnd);

			while (rst.next()) {
				MobileBean bean = new MobileBean();
				bean.setMobileid(rst.getInt(1));
				bean.setName(rst.getString(2));
				bean.setPrice(rst.getInt(3));
				bean.setQuantity(rst.getString(4));
				MblList.add(bean);
			}
			if (MblList.isEmpty()) {
				logger.error("exception while fetching details..\n");
				throw new MobileException("No mobiles found between " + min
						+ " and " + max);
			} else {
				logger.info("details fetched from mobiles table..\n");
			}
		} catch (SQLException e) {
			System.out.println(e);

		}
		return MblList;
		/*
		 @Override
	public MobileBean viewMobById(int viewId) throws MobileException
	{
		Connection con= null;
		Statement stmt =null;
		MobileBean bean= new MobileBean();
		
		try {
			logger.debug("connecting to database for viewing details of mobile by id..");
			con=DBConnection.getConnection();
			String cmd="select mobileid,name,price,quantity from mobiles where mobileid ="+ viewId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setMobileid(result.getInt(1));
					bean.setName(result.getString(2));
					bean.setPrice(result.getInt(3));
					bean.setQuantity(result.getString(4));
					logger.info("details fetched from mobiles table..\n");	
				}
			 else
			 {
				 logger.error("exception while fetching details..\n");
				 throw new MobileException("Id not found!");
			 }
		}
		 catch (SQLException e) 
		{
			System.out.println("database error!");
		}
		return bean;	
	}
		 */

	}
}
