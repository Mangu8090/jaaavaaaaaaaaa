package com.ems.dao.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import com.emp.exception.MobileException;
import com.emp.util.DBConnection;

public class TestCon {
 
	
	@Test
	public void testconnection() throws MobileException {
		 Connection con = DBConnection.getConnection();
		 assertNotNull(con);
	}
     
	@Ignore
     @Test
     (expected=MobileException.class) // testing for exception
 	public void testconnectionfail() throws MobileException {
 		 Connection con = DBConnection.getConnection();
 	}
    
     
     
}
